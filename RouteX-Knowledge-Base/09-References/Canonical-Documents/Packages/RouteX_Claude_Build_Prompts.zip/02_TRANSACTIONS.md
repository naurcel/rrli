# RouteX Transactions

Track company expenses not tied to deliveries.

Categories:
- Insurance
- Registration
- Maintenance
- Utilities
- Rent
- Equipment
- Office Supplies
- Other
