# RouteX Design Language

Use Readex Pro.
Avoid maps, truck illustrations, hero sections, analytics walls, and decorative graphics.
Favor tables, drawers, search, and operational workflows.
