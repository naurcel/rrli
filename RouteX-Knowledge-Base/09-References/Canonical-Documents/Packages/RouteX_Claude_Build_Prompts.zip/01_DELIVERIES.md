# RouteX Deliveries

Primary operational workspace.

Features:
- Summary cards
- Delivery table
- Search
- Filters
- Sorting
- Pagination
- Delivery Details Drawer
- Edit Delivery Drawer
