# RouteX Settings

Profile
Password
Appearance
Dark Mode
