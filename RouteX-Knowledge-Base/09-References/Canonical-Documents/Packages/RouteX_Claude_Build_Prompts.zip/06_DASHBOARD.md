# RouteX Dashboard

Build after other modules.

Revenue
Expenses
Net Margin
Margin %
Recent Deliveries
Attention Needed
Top Trucks
Revenue vs Expenses
Quick Actions
