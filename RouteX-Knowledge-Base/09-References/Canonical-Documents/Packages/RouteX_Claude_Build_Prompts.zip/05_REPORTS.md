# RouteX Reports

Tabs:
- Revenue
- Expenses
- Profitability
- Operations
