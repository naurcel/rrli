# RouteX Foundation Build

Build the application shell only.

Tech Stack:
- Next.js 15
- TypeScript
- Tailwind CSS
- shadcn/ui
- Lucide React
- Recharts
- next-themes
- Readex Pro

Create reusable layout, navigation, search, theme, and mock data infrastructure.
