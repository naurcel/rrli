# RouteX Design Language

## Product Personality
A premium, calm, profitability-focused operations workspace.

## Visual References
Linear, Stripe Dashboard, Mercury, modern ERP software.

## Avoid
- Maps
- GPS visuals
- Truck illustrations
- Hero sections
- Analytics walls
- Giant KPI grids
- Marketing layouts
- Gradient-heavy cards
- Glassmorphism

## Typography
Readex Pro only.
Weights: 400, 500, 600.

## Cards
24px radius.
White surfaces.
Thin borders.
Soft shadows.

## Color System
Blue = Revenue
Amber = Expenses
Green = Margin
Purple = Margin %
Red = Delays / Missing POD

Never use fully colored KPI cards.

## Tables
Tables are first-class citizens.
Design around records, not widgets.

## Drawers
Delivery details and editing occur in right-side drawers.
Preserve context.

## North Star
Every element must answer:
'What decision does this help the user make?'