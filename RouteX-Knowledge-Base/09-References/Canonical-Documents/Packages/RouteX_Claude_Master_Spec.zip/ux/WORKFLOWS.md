# Core Workflow

Search
→ Open Record
→ Review
→ Update
→ Continue Working

Never force unnecessary page transitions.