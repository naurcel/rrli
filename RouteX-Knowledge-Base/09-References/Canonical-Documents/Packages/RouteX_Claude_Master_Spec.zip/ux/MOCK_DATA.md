# Mock Data Requirements

6 owned trucks
15 subcontracted trucks
100 deliveries
50 transactions
10 users

Use Cavite and NCR locations.
Use Philippine Peso formatting.