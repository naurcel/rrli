# Components

Use shadcn/ui.

Required:
Sidebar
Header
Search
Cards
Tables
Drawers
Filters
Charts

Charts are supporting elements only.