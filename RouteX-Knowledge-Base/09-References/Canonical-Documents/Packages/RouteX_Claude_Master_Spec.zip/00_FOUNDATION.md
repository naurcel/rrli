# Foundation Build

Build:
- App shell
- Sidebar
- Header
- Theme provider
- Global search
- Mock data architecture

Navigation:
Dashboard
Fleet
Deliveries
Transactions
Reports
Administration
Settings

Do not build pages yet.