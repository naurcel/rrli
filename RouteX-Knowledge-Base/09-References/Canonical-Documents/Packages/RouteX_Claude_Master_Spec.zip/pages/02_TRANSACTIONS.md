# Transactions

Purpose:
Track company expenses not tied to deliveries.

Categories:
Insurance
Registration
Maintenance
Utilities
Rent
Office Supplies
Equipment
Other

Table-first experience.
Drawer-based editing.