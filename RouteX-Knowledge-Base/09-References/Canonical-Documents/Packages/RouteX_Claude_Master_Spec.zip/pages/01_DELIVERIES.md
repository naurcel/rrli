# Deliveries

Purpose:
Primary operational workspace.

Summary Cards:
- All Deliveries
- Pending
- In Transit
- Delivered
- Missing POD

Table Columns:
Delivery ID
Date
Client
Truck
Driver
Route
Status
Revenue
Expenses
Margin
POD

Drawer:
Overview
Financials
POD Uploads
Remarks

Editing happens inside drawer.