# Fleet

Owned Trucks:
Card grid.

Subcontracted Trucks:
Table.

Filters:
Owned
Subcontracted
Active
Inactive

Truck cards open Truck Profile.