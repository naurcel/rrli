# Reports

Tabs:
Revenue
Expenses
Profitability
Operations

Reports should look like printable business documents.

Exports:
PDF
Excel
Print