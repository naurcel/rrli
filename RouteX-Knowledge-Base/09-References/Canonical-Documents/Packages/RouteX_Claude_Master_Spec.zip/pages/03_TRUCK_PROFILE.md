# Truck Profile

Most important page.

Order:
1 Revenue
2 Expenses
3 Margin
4 Margin %

Then:
Expense Breakdown
Delivery History

Users should instantly understand profitability.