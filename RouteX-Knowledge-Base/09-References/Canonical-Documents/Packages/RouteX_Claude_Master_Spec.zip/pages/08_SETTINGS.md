# Settings

Profile
Password
Appearance

Themes:
Light
Dark
System