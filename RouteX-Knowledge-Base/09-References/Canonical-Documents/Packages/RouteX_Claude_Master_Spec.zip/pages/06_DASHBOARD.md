# Dashboard

Build last.

Summary:
Revenue
Expenses
Net Margin
Margin %

Sections:
Recent Deliveries
Attention Needed
Top Trucks
Revenue vs Expenses
Quick Actions

No analytics overload.