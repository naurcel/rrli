# RouteX Master Spec

Use these files sequentially with Claude Code.
Build foundation first, then pages.