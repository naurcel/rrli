# RouteX Product Overview

RouteX is an internal operations platform for Redeemed Route Logistics Inc.

Core purpose:
- Delivery management
- Truck profitability management
- Proof of Delivery management
- Reporting
- Operations visibility

Not included:
- GPS tracking
- Route optimization
- Fleet telematics
- Customer portal

Primary workflow:
Search → Open Record → Review → Update → Continue Working
