# Data Model

Truck
- id
- plateNumber
- driver
- ownership
- status
- truckType

Delivery
- id
- date
- client
- truckId
- route
- revenue
- expenses
- margin
- status

POD
- id
- deliveryId
- fileUrl
- uploadedAt

User
- id
- name
- email
- role
