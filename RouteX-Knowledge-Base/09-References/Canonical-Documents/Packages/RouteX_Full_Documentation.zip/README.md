# RouteX Documentation Package

Use these specifications as the source of truth for building:

- Next.js 15
- TypeScript
- Tailwind CSS
- shadcn/ui
- Lucide Icons
- next-themes
- Recharts

Core Principle:

Every element must answer:
'What decision does this help the user make?'

Design RouteX as mature operational software, not a dashboard showcase.
