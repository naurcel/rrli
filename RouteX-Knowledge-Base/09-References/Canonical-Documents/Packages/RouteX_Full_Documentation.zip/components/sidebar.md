# Sidebar Component

Light theme.
Collapsed by default.
Icon-first navigation.
Expandable labels.
