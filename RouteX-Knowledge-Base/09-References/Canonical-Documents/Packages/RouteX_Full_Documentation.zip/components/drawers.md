# Drawer Patterns

Used for:
- Delivery Details
- Edit Delivery

Do not navigate away from tables.
Preserve user context.
