# Header Component

Contains:
- Search
- Date Filter
- Notifications
- User Menu
