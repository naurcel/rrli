# Design System

Font: Readex Pro
Weights: 400, 500, 600

Radius:
- Cards: 24px
- Inputs: 12px
- Buttons: 10px

Theme:
- Light first
- Dark mode supported

Visual Style:
- Stripe
- Linear
- Mercury
- Modern ERP systems

Avoid:
- Maps
- Truck illustrations
- Hero sections
- Glassmorphism
- Analytics walls
- Decorative graphics
