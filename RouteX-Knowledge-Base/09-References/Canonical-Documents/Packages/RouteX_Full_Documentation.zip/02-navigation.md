# Navigation

Sidebar:
- Dashboard
- Fleet
- Deliveries
- Reports
- Administration
- Settings

Collapsed by default.

Header:
- Global Search
- Date Filter
- Notifications
- User Menu

Search supports:
- Plate Number
- Delivery ID
- Driver
- Client
