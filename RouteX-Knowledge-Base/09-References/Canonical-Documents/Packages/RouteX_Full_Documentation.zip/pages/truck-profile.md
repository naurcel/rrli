# Truck Profile

Most important page.

Overview:
- Plate Number
- Driver
- Status
- Truck Type

Financial Performance:
- Revenue
- Expenses
- Margin
- Margin %

Expense Breakdown:
- Diesel
- Labor
- Toll
- Other

Delivery History Table:
- Date
- Client
- Route
- Revenue
- Expenses
- Margin
- POD
