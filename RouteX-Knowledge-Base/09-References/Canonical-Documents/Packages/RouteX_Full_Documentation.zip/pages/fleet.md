# Fleet

Purpose:
Truck profitability management.

Filters:
- Owned
- Subcontracted
- Active
- Inactive

Owned Trucks:
Card Grid

Fields:
- Plate Number
- Driver
- Status
- Revenue
- Expenses
- Margin

Subcontracted Trucks:
Table Layout
