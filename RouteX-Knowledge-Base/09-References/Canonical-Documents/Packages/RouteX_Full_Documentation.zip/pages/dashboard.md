# Dashboard

Purpose:
Business overview and operational awareness.

Sections:
1. Revenue
2. Expenses
3. Net Margin
4. Margin %

Recent Deliveries table:
- Delivery ID
- Client
- Truck
- Status
- Margin
- POD

Attention Needed:
- Delayed Deliveries
- Missing POD
- Pending Review

Top Trucks:
Revenue | Margin | Margin % | Trips | Expenses

Revenue vs Expenses:
Single supporting chart.

Quick Actions:
- New Delivery
- Upload POD
- Generate Report
