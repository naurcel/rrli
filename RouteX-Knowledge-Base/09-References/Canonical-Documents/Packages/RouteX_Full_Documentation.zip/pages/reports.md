# Reports

Tabs:
- Revenue
- Expenses
- Profitability
- Operations

Exports:
- PDF
- Excel
- Print

Reports should resemble business documents.
