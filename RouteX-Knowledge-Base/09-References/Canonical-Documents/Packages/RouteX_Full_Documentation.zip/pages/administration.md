# Administration

Sections:
- Users
- Roles
- Activity Logs
- Company Expenses

Roles:
- Admin
- Manager
- Operations Staff
