# Deliveries

Primary workspace.

Summary Cards:
- All Deliveries
- Pending
- In Transit
- Delivered
- Missing POD

Table:
- Delivery ID
- Date
- Client
- Truck
- Driver
- Route
- Status
- Revenue
- Expenses
- Margin
- POD

Delivery Details:
Right-side drawer.

Edit Delivery:
Inline drawer editing.
