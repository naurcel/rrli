
# ROUTEX_UI_BLUEPRINT.md

## Layout Grid

Desktop:
- Max content width: 1440px
- Page padding: 32px
- Section gap: 24px
- Card gap: 20px

Dashboard:
- Centered feeling
- Comfortable whitespace

Fleet / Deliveries / Transactions / Reports:
- Wide workspace layout
- Table-first

## Sidebar

Width Expanded: 240px
Width Collapsed: 72px

Style:
- Light surface
- Thin right border
- No gradients
- No shadows

Collapsed by default.

## Header

Height: 72px

Contains:
- Search
- Date filter
- Notifications
- User menu

Search width:
- 320px to 420px

Not dominant.

## Cards

Radius: 24px
Border: subtle neutral
Shadow: soft

Padding:
- 24px

No colored backgrounds.

## Tables

Row Height:
- 52px to 56px

Sticky headers.

Hover states.

Designed as primary interface elements.

## Drawers

Width:
- 520px to 640px

Used for:
- Delivery Details
- Edit Delivery
- Transaction Details
- Edit Transaction

Preserve context.

## Typography

Font:
Readex Pro

Page Title:
- 30px
- Weight 600

Section Title:
- 20px
- Weight 600

Card Title:
- 14px
- Weight 500

Body:
- 14px

Supporting:
- 12px

## Color Tokens

Revenue:
Blue

Expenses:
Amber

Margin:
Green

Margin %:
Purple

Issues:
Red

Apply color through badges, accents, and indicators only.

## Dark Mode

Maintain identical hierarchy.

Avoid pure black.

Use muted surfaces.

## Responsive

Desktop First.

Tablet:
- Collapse sidebar automatically

Mobile:
- Drawer navigation

## Anti-Patterns

Do NOT use:
- Hero banners
- Maps
- Truck illustrations
- KPI walls
- Gradient cards
- Glassmorphism
- Decorative widgets
- Marketing layouts

## Final Rule

Design for repeated daily use by operations staff.
