# RouteX v1 Product Spec

This package is the source of truth for:
- UX
- UI
- Architecture
- Data Modeling

RouteX is a profitability-focused trucking operations workspace.
