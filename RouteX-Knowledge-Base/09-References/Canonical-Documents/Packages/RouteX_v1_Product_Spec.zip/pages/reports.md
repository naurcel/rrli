# Reports

Tabs:
Revenue
Expenses
Profitability
Operations

Exports:
PDF
Excel
Print

Profitability Formula:
Revenue
- Delivery Expenses
- Company Expenses
= Net Business Profit
