# Administration

Users
Roles
Activity Logs

Roles:
Admin
Manager
Operations Staff
CSR
