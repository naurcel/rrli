# Dashboard

Purpose:
Business overview and operational awareness.

Widgets:
- Revenue
- Expenses
- Net Margin
- Margin %

Expenses = Delivery Expenses + Company Expenses

Sections:
- Recent Deliveries
- Attention Needed
- Top Trucks Ranking
- Revenue vs Expenses
- Quick Actions

All widgets navigate to source records.
