# Deliveries

Primary operational workspace.

Table columns:
Delivery ID
Date
Client
Truck
Driver
Route
Status
Revenue
Expenses
Margin
POD

Details open in right-side drawer.
