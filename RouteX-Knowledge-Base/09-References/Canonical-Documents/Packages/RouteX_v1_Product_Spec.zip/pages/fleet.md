# Fleet

Truck profitability workspace.

Owned Trucks:
Card layout

Subcontracted Trucks:
Table layout

Filters:
Owned
Subcontracted
Active
Inactive
