# Transactions

Purpose:
Track company expenses not tied to deliveries.

Examples:
- Insurance
- Registration
- Maintenance
- Utilities
- Rent
- Office Supplies
- Equipment

Table Columns:
Transaction ID
Date
Category
Description
Amount
Entered By

Details open in right-side drawer.
