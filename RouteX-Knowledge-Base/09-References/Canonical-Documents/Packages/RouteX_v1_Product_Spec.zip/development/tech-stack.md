# Tech Stack

Next.js 15
TypeScript
Tailwind CSS
shadcn/ui
Lucide Icons
Recharts
next-themes

Light theme first.
Dark mode supported.
