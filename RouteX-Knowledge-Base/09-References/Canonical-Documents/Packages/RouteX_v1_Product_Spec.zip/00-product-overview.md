# RouteX Product Specification v1.0

RouteX is an internal operations and profitability platform for Redeemed Route Logistics Inc.

Primary goals:
- Delivery Management
- Truck Profitability Visibility
- Proof of Delivery Management
- Company Expense Tracking
- Business Reporting

Not included:
- GPS Tracking
- Route Optimization
- Telematics
- Customer Portal
- Live Maps
