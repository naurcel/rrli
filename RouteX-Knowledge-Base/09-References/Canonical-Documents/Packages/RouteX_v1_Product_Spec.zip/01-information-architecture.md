# Information Architecture

Dashboard
Fleet
Deliveries
Transactions
Reports
Administration
Settings

Global Search available everywhere.
