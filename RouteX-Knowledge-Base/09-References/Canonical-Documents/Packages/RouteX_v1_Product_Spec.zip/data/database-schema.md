# Core Entities

Truck
Delivery
Transaction
POD
Expense
User
ActivityLog

Delivery Expenses:
Diesel
Labor
Toll
Other

Company Expenses:
Insurance
Maintenance
Utilities
Rent
Office Supplies
Equipment
Other
