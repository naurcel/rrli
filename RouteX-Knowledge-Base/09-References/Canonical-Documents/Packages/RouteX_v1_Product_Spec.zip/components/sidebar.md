# Sidebar

Collapsed by default.
Light theme.
Icons first.
Expandable labels.
