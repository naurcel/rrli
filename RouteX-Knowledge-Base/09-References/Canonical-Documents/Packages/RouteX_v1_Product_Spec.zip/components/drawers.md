# Drawer Pattern

Used by:
Delivery Details
Edit Delivery
Transaction Details
Edit Transaction

Never navigate away when editing.
