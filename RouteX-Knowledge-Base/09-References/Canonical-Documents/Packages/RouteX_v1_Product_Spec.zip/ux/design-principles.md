# Design Principles

Readex Pro

Avoid:
- Maps
- Hero sections
- Truck illustrations
- Analytics walls
- Decorative graphics

Favor:
- Tables
- Search
- Drawers
- Filters
- Record management

Every element must answer:
What decision does this help the user make?
