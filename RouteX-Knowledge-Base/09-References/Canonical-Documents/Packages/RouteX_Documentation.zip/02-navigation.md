# Navigation

Dashboard
Fleet
Deliveries
Reports
Administration
Settings
